$(document).ready(function() {
				$("#owl-demo").owlCarousel({
					autoPlay: 3000,
					navigation: true,
					slideSpeed: 300,
					paginationSpeed: 400,
					singleItem: true
				});
				$("#owl-demo2").owlCarousel({
					autoPlay: 3000,
					items: 4,
					itemsDesktop: [1199, 3],
					itemsDesktopSmall: [979, 3]
				});
				$(".owltest").owlCarousel({
					autoPlay: 4000,
					navigation: false,
					slideSpeed: 300,
					paginationSpeed: 400,
                                        itemsDesktop: [1199, 3],
					itemsDesktopSmall: [979, 3],
					singleItem: true
				});
				$("#owl-demo3").owlCarousel({
					autoPlay: 3000,
					navigation: true,
					slideSpeed: 300,
					paginationSpeed: 400,
					singleItem: true
				});
				$("#owl-demo4").owlCarousel({
					autoPlay: 3000,
					items: 4,
					itemsDesktop: [1199, 3],
					itemsDesktopSmall: [979, 3]
				});
				$("#owl-demo5").owlCarousel({
					autoPlay: 3000,
					navigation: true,
					slideSpeed: 300,
					paginationSpeed: 400,
					singleItem: true
				});
				$("#owl-demo6").owlCarousel({
					autoPlay: 3000,
					items: 4,
					itemsDesktop: [1199, 3],
					itemsDesktopSmall: [979, 3]
				});
				$("#owl-demo7").owlCarousel({
					autoPlay: 3000,
					navigation: true,
					slideSpeed: 300,
					paginationSpeed: 400,
					singleItem: true
				});
				$("#owl-demo8").owlCarousel({
					autoPlay: 3000,
					items: 4,
					itemsDesktop: [1199, 3],
					itemsDesktopSmall: [979, 3]
				});
			});