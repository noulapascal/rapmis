<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;
use App\Entity\Students;
use Symfony\Component\HttpFoundation\Request;

class SearchController extends AbstractController
{
    /**
     * @Route("/search", name="search")
     */
    public function index()
    {
        return $this->render('search/index.html.twig', [
            'controller_name' => 'SearchController',
        ]);
    }
    
    /**
     * @Route("/student_search", name="student_search")
     * 
     */
    public function searchStudent(\Symfony\Component\HttpFoundation\Request $request) {
         $form = $this->createForm(\App\Form\SearchType::class);
         $form->handleRequest($request);
         if($form->isSubmitted() && $form->isValid()){
             
             $title = $form->get('title')->getData();
             $school= $this->getDoctrine()->getManager()->getRepository(\App\Entity\Etablissements::class)->find(5);
               $rep = $this->getDoctrine()->getManager()->getRepository(Students::class)->Adminsearch($title,$school);
       // var_dump($rep);
        //dump($rep);
      
         }
         if(empty($rep)){
             $rep=[];
         }
           return $this->render('search/new.html.twig',[
            'form'=>$form->createView(),
           'rep'=> $rep ? $rep : []
        ]);
      
    }
}
