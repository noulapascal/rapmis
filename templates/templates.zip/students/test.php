<body class="page-header-fixed sidemenu-closed-hidelogo page-content-white page-md header-white white-sidebar-color logo-indigo">
<div class="page-wrapper">
    <!-- start header -->
    <div class="page-header navbar navbar-fixed-top ">
        <div class="page-header-inner ">
            <!-- logo start -->
            <div class="page-logo">
                <a href="/rapmis/web/">
                    <span class="logo-icon material-icons fa-rotate-45">school</span>
                    <span class="logo-default">RAPMIS</span> </a>
            </div>
            <!-- logo end -->
            <ul class="nav navbar-nav navbar-left in">
                <li><a href="#" class="menu-toggler sidebar-toggler"><i class="icon-menu"></i></a></li>
            </ul>
           <!-- <form class="search-form-opened" action="#" method="GET">
                <div class="input-group">
                    <input type="text" class="form-control" placeholder="Search..." name="query">

                    <span class="input-group-btn">
                          <a href="javascript:;" class="btn submit">
                             <i class="icon-magnifier"></i>
                           </a>
                        </span>
                </div>
            </form>
--
            <!-- start mobile menu -->
            <a href="javascript:;" class="menu-toggler responsive-toggler" data-toggle="collapse" data-target=".navbar-collapse">
                <span></span>
            </a>
            <!-- end mobile menu -->
            <!-- start header menu -->


            <div class="top-menu">
               
                <ul class="nav navbar-nav pull-right">
                    <li><a href="javascript:;" class="fullscreen-btn"><i class="fa fa-arrows-alt"></i></a></li>
                    <!-- start language menu -->
                    
                    <li><a href="/rapmis/web/contact/new" class="btn btn-info btn-sm">Envoyez nous un message </a>  
                            </li>
                            <li><a href="tel:+237697019629" class="btn btn-success btn-sm"> <strong>Appelez-nous</strong></a></li>




           <!-- end language menu -->
                    <!-- start notification dropdown -->
                                      <!--  <li class="dropdown dropdown-extended dropdown-notification" id="header_notification_bar">
                        <a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" data-close-others="true">
                            <i class="fa fa-bell-o"></i>
                            <span class="badge headerBadgeColor1"> 6 </span>
                        </a>
                        <ul class="dropdown-menu">
                            <li class="external">
                                <h3><span class="bold">Notifications</span></h3>
                                <span class="notification-label purple-bgcolor">New 6</span>
                            </li>
                            <li>
                                <ul class="dropdown-menu-list small-slimscroll-style" data-handle-color="#637283">
                                    <li>
                                        <a href="javascript:;">
                                            <span class="time">just now</span>
                                            <span class="details">
                                                <span class="notification-icon circle deepPink-bgcolor"><i class="fa fa-check"></i></span> Congratulations!. </span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="javascript:;">
                                            <span class="time">3 mins</span>
                                            <span class="details">
                                                <span class="notification-icon circle purple-bgcolor"><i class="fa fa-user o"></i></span>
                                                <b>John Micle </b>is now following you. </span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="javascript:;">
                                            <span class="time">7 mins</span>
                                            <span class="details">
                                                <span class="notification-icon circle blue-bgcolor"><i class="fa fa-comments-o"></i></span>
                                                <b>Sneha Jogi </b>sent you a message. </span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="javascript:;">
                                            <span class="time">12 mins</span>
                                            <span class="details">
                                                <span class="notification-icon circle pink"><i class="fa fa-heart"></i></span>
                                                <b>Ravi Patel </b>like your photo. </span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="javascript:;">
                                            <span class="time">15 mins</span>
                                            <span class="details">
                                                <span class="notification-icon circle yellow"><i class="fa fa-warning"></i></span> Warning! </span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="javascript:;">
                                            <span class="time">10 hrs</span>
                                            <span class="details">
                                                <span class="notification-icon circle red"><i class="fa fa-times"></i></span> Application error. </span>
                                        </a>
                                    </li>
                                </ul>
                                <div class="dropdown-menu-footer">
                                    <a href="javascript:void(0)"> {% trans %} All notifications  {% endtrans %} Classes</a>
                                </div>
                            </li>
                        </ul>
                    </li>
                    <!-- end notification dropdown -->
                    <!-- start message dropdown -->

                   <!-- <li class="dropdown dropdown-extended dropdown-inbox" id="header_inbox_bar">
                        <a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" data-close-others="true">
                            <i class="fa fa-envelope-o"></i>
                            <span class="badge headerBadgeColor2"> 2 </span>
                        </a>
                        <ul class="dropdown-menu">
                            <li class="external">
                                <h3><span class="bold">Messages</span></h3>
                                <span class="notification-label cyan-bgcolor">New 2</span>
                            </li>
                            <li>
                                <ul class="dropdown-menu-list small-slimscroll-style" data-handle-color="#637283">
                                    <li>
                                        <a href="#">
                                                <span class="photo">
                                                	<img src="/rapmis/web/assets/img/prof/prof2.jpg" class="img-circle" alt=""> </span>
                                            <span class="subject">
                                                	<span class="from"> Sarah Smith </span>
                                                	<span class="time">Just Now </span>
                                                </span>
                                            <span class="message"> Jatin I found you on LinkedIn... </span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#">
                                                <span class="photo">
                                                	<img src="/rapmis/web/assets/img/prof/prof3.jpg" class="img-circle" alt=""> </span>
                                            <span class="subject">
                                                	<span class="from"> John Deo </span>
                                                	<span class="time">16 mins </span>
                                                </span>
                                            <span class="message"> Fwd: Important Notice Regarding Your Domain Name... </span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#">
                                                <span class="photo">
                                                	<img src="/rapmis/web/assets/img/prof/prof1.jpg" class="img-circle" alt=""> </span>
                                            <span class="subject">
                                                	<span class="from"> Rajesh </span>
                                                	<span class="time">2 hrs </span>
                                                </span>
                                            <span class="message"> pls take a print of attachments. </span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#">
                                                <span class="photo">
                                                	<img src="/rapmis/web/assets/img/prof/prof8.jpg" class="img-circle" alt=""> </span>
                                            <span class="subject">
                                                	<span class="from"> Lina Smith </span>
                                                	<span class="time">40 mins </span>
                                                </span>
                                            <span class="message"> Apply for Ortho Surgeon </span>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#">
                                                <span class="photo">
                                                	<img src="/rapmis/web/assets/img/prof/prof5.jpg" class="img-circle" alt=""> </span>
                                            <span class="subject">
                                                	<span class="from"> Jacob Ryan </span>
                                                	<span class="time">46 mins </span>
                                                </span>
                                            <span class="message"> Request for leave application. </span>
                                        </a>
                                    </li>
                                </ul>
                                <div class="dropdown-menu-footer">
                                    <a href="#"> {% trans %} All  Messages{% endtrans %}</a>
                                </div>
                            </li>
                        </ul>
                    </li> -->
                    <!-- end message dropdown -->
                    <!-- start manage user dropdown -->







                    <li class="dropdown dropdown-user">
                        <a href="javascript:;" class="dropdown-toggle" data-toggle="dropdown" data-hover="dropdown" data-close-others="true">
                                                       <img alt="" class="img-circle img-responsive img-rounded" src="/rapmis/web/uploads/user/index.png" width="32px">
                                                        <span class="username username-hide-on-mobile"> Habitech </span>
                            <i class="fa fa-angle-down"></i>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-default">
                                                            <li><a href="/rapmis/web/profile/edit">
                                        Logged in as Habitech
                                    </a>
                                </li>
                                                        <li>
                                <a href="/rapmis/web/profile/">
                                    <i class="icon-user"></i> Profile </a>
                            </li>
                                                        <li>
                                <a href="/rapmis/web/use/">
                                    <i class="fa fa-user"></i> Create user
                                </a>
                            </li>
                                                                                    <li>
                                <a href="#">
                                    <i class="icon-directions"></i> Help
                                </a>
                            </li>
                            <li class="divider"> </li>
                            <li>
                                <a href="lock_screen.html">
                                    <i class="icon-lock"></i> Lock
                                </a>
                            </li>
                            <li>
                                <a href="/rapmis/web/logout">
                                    <i class="icon-logout"></i> Log out </a>
                            </li>
                        </ul>
                    </li>
                    
                    <!-- end manage user dropdown -->
                                        <li class="dropdown language-switch">

                        <a class="dropdown-toggle" data-toggle="dropdown" aria-expanded="false">
                            <img src="/rapmis/web/assets/img/flags/Cameroun.png" class="position-left" alt="" width="32px"> <span class="fa fa-pencil"></span>
                        </a>

                        <!-- <ul class="dropdown-menu">
                            <li>
                                <a class="deutsch"><img src="/rapmis/web/assets/img/flags/Cameroun.png" alt="" width="32px"> Français</a>
                            </li>
                            <li>
                                <a class="english"><img src="/rapmis/web/assets/img/flags/gb.png" alt=""> English</a>
                            </li>


                        </ul>-->
                    </li>

                    <li class="dropdown dropdown-quick-sidebar-toggler">
                        <a id="headerSettingButton" class="mdl-button mdl-js-button mdl-button--icon pull-right" data-upgraded=",MaterialButton">
                            <i class="material-icons">more_vert</i>
                        </a>
                    </li>
                </ul>
            </div>

        </div>
    </div>



    <!-- end header -->
    <!-- start color quick setting -->
    <div class="quick-setting-main">
        <button class="control-sidebar-btn btn" data-toggle="control-sidebar"><i class="fa fa-cog fa-spin"></i></button>
        <div class="quick-setting display-none">
            <ul id="themecolors">
                <li><p class="selector-title">Main Layouts</p></li>
                <li class="complete"><div class="theme-color layout-theme">
                        <a href="#" data-theme="light"><span class="head"></span><span class="cont"></span></a>
                        <a href="#" data-theme="dark">
                            <span class="head"></span><span class="cont"></span></a>
                    </div></li>
                <li><p class="selector-title">Sidebar Color</p></li>
                <li class="complete"><div class="theme-color sidebar-theme">
                        <a href="#" data-theme="white"><span class="head"></span><span class="cont"></span></a>
                        <a href="#" data-theme="dark"><span class="head"></span><span class="cont"></span></a>
                        <a href="#" data-theme="blue"><span class="head"></span><span class="cont"></span></a>
                        <a href="#" data-theme="indigo"><span class="head"></span><span class="cont"></span></a>
                        <a href="#" data-theme="cyan"><span class="head"></span><span class="cont"></span></a>
                        <a href="#" data-theme="green"><span class="head"></span><span class="cont"></span></a>
                        <a href="#" data-theme="red"><span class="head"></span><span class="cont"></span></a>
                    </div></li>
                <li><p class="selector-title">Header Brand color</p></li>
                <li class="theme-option"><div class="theme-color logo-theme">
                        <a href="#" data-theme="logo-white"><span class="head"></span><span class="cont"></span></a>
                        <a href="#" data-theme="logo-dark"><span class="head"></span><span class="cont"></span></a>
                        <a href="#" data-theme="logo-blue"><span class="head"></span><span class="cont"></span></a>
                        <a href="#" data-theme="logo-indigo"><span class="head"></span><span class="cont"></span></a>
                        <a href="#" data-theme="logo-cyan"><span class="head"></span><span class="cont"></span></a>
                        <a href="#" data-theme="logo-green"><span class="head"></span><span class="cont"></span></a>
                        <a href="#" data-theme="logo-red"><span class="head"></span><span class="cont"></span></a>
                    </div></li>
                <li><p class="selector-title">Header color</p></li>
                <li class="theme-option"><div class="theme-color header-theme">
                        <a href="#" data-theme="header-white"><span class="head"></span><span class="cont"></span></a>
                        <a href="#" data-theme="header-dark"><span class="head"></span><span class="cont"></span></a>
                        <a href="#" data-theme="header-blue"><span class="head"></span><span class="cont"></span></a>
                        <a href="#" data-theme="header-indigo"><span class="head"></span><span class="cont"></span></a>
                        <a href="#" data-theme="header-cyan"><span class="head"></span><span class="cont"></span></a>
                        <a href="#" data-theme="header-green"><span class="head"></span><span class="cont"></span></a>
                        <a href="#" data-theme="header-red"><span class="head"></span><span class="cont"></span></a>
                    </div></li>
            </ul>
        </div>
    </div>
    <!-- end color quick setting -->
    <!-- start page container -->
    <div class="page-container">
        <!-- start sidebar menu -->
                                
        <div class="sidebar-container">
            <div class="sidemenu-container navbar-collapse collapse fixed-menu">
                <div id="remove-scroll" class="left-sidemenu">
                    <div class="slimScrollDiv" style="position: relative; overflow: hidden; width: auto; height: 585px;"><ul class="sidemenu  page-header-fixed slimscroll-style" data-keep-expanded="false" data-auto-scroll="true" data-slide-speed="200" style="padding-top: 20px; overflow: hidden; width: auto; height: 585px;">
                        <li class="sidebar-toggler-wrapper hide">
                            <div class="sidebar-toggler">
                                <span></span>
                            </div>
                        </li>

                        
                        
                            <li class="sidebar-user-panel">
                            <div class="user-panel">
                                                                <div class="pull-left image">
                                    <img src="/rapmis/web/uploads/user/index.png" class="img-circle user-img-circle" alt="User Image" width="100px" height="100px">
                                </div>
                                                            <div class="pull-left info">
                                    <p> Habitech</p>
                                    <a href="#"><i class="fa fa-circle user-online"></i><span class="txtOnline"> Online</span></a>
                                </div>
                            </div>
                        </li>
                                                
                                                      
                             <li class="nav-item">
                                        <a href="/rapmis/web/country/" class=" nav-link nav-toggle arrow">
                                            <span class="material-icons">group</span>
                                            <span class="title">Manage User</span>
                                                                                    </a>
                                            <ul class="sub-menu">
                                                <li class="nav-item "><a href="/rapmis/web/use/">Créer un administrateur</a></li>
                                                <li class="nav-item ">
                                                    <a href="/rapmis/web/country/" class=" nav-link nav-toggle arrow">
                                                        <span class="title">Etat</span> <span class="arrow"></span></a>
                                                
                                                <ul class="sub-menu ">
                                                    <li class="nav-item "><a href="/rapmis/web/use/inspect_create/%7Bcountry%3F%7D">Créer un Utilisateur communal</a></li>
                                                    <li class="nav-item "><a href="/rapmis/web/use/dep_sel">Créer un Utilisateur departemental</a></li>
                                                    <li class="nav-item "><a href="/rapmis/web/use/reg_sel">Créer un Utilisateur regional</a></li>
                                                    <li class="nav-item "><a href="/rapmis/web/use/min_create/%7Bcountry%3F%7D">Créer un Utilisateur ministeriel</a></li>
                                                </ul></li>
                                            </ul>
                                    </li>

                                
                                <li class="nav-item ">
                                        <a href="/rapmis/web/country/" class="nav-link ">
                                            <span class="title">Country</span>
                                        </a>
                                    </li>
                                    
                                    <li class="nav-item ">
                                     </li><li class="nav-item ">
                                        <a href="/rapmis/web/students/{% trans %} All  {% endtrans %}" class="nav-link ">
                                            <span class="title">School Management</span>
                                            <span class="selected"></span>
                                        </a>
                                    </li>
                                                               
                        
                                                <li class="nav-item">
                            <a href="#" class="nav-link nav-toggle"> <i class="material-icons">person</i>
                                <span class="title">{% trans %}Teacher{% endtrans %} s</span> <span class="arrow"></span>
                            </a>
                            <ul class="sub-menu">
                                <li class="nav-item">
                                    <a href="/rapmis/web/teacher/" class="nav-link "> <span class="title">{% trans %} All  Teachers{% endtrans %}</span>
                                    </a>
                                </li>
                              
                                
                            </ul>
                        </li>
                                                                                
                        <li class="nav-item">
                            <a href="#" class="nav-link nav-toggle"><i class="material-icons">group</i>
                                <span class="title">Students</span><span class="arrow"></span></a>
                            <ul class="sub-menu">
                                 
                              

                                                                
                                
                                                                <li class="nav-item">
                                    <a href="/rapmis/web/students/{% trans %} All  {% endtrans %}" class="nav-link "> <span class="title">{% trans %} All  Students{% endtrans %} of country </span>
                                    </a>
                                </li>
                                <li>
                                    <a href="/rapmis/web/students/upload" class="nav-link "> <span class="title">Upload students (excel file) </span>
                                    </a>
                                </li>

                                
                                                                                                                             </ul>
                        </li>
                        
                                 <li class="nav-item">
                            <a href="#" class="nav-link nav-toggle"> <i class="material-icons">local_library</i>
                                <span class="title">{% trans %} Discipline{% endtrans %}</span> <span class="arrow"></span>
                            </a>
                            <ul class="sub-menu">
                                                                                             </ul>
                        </li>   

                        <li class="nav-item">
                                    <a href="/rapmis/web/distinction/new" class="nav-link "> <span class="title">Add Distinction</span>
                                    </a>
                                </li>

                                                
                        
                                                                                         
                        <li class="nav-item">
                            <a href="#" class="nav-link nav-toggle"> <i class="material-icons">school</i>
                                <span class="title">Courses</span> <span class="arrow"></span>
                            <!--    <span class="label label-rouded label-menu label-success">new</span> -->
                            </a>
                            <ul class="sub-menu">
                                <li class="nav-item">
                                    <a href="/rapmis/web/matieres/" class="nav-link "> <span class="title">{% trans %} All Courses  {% endtrans %} Classes</span>
                                    </a>
                                </li>
                                                                                                 <li class="nav-item">
                                    <a href="/rapmis/web/niveau/" class="nav-link "> <span class="title">{% trans %} All  Level {% endtrans %} </span>
                                    </a>
                                </li>
                                                                                             </ul>
                        </li>
                        
                                
                        <li class="nav-item">
                            <a href="/rapmis/web/lienutile/" class="nav-link "> <i class="material-icons">business</i>
                                <span class="title">importants links</span> <span class="arrow"></span>
                            </a>
                        </li>
                                                                    </ul><div class="slimScrollBar" style="background: rgb(158, 165, 171) none repeat scroll 0% 0%; width: 5px; position: absolute; top: 0px; opacity: 0.4; display: none; border-radius: 7px; z-index: 99; right: 1px; height: 504.013px;"></div><div class="slimScrollRail" style="width: 5px; height: 100%; position: absolute; top: 0px; display: none; border-radius: 7px; background: rgb(51, 51, 51) none repeat scroll 0% 0%; opacity: 0.2; z-index: 90; right: 1px;"></div></div>
                        
                        <li class="nav-item">
                            <a href="#" class="nav-link nav-toggle"> <i class="material-icons">face</i>
                                <span class="title">Staff</span> <span class="arrow"></span>
                            </a>
                            <ul class="sub-menu">
                                <li class="nav-item">
                                    <a href="/rapmis/web/staff/" class="nav-link "> <span class="title">{% trans %} All  Staff{% endtrans %} </span>
                                    </a>
                                </li>
                                                                                             </ul>
                        </li>
                        
                        
                       <!--  <li class="nav-item">
                            <a href="#" class="nav-link nav-toggle"> <i class="material-icons">airline_seat_individual_suite</i>
                                <span class="title">Holiday</span> <span class="arrow"></span>
                            </a>
                           <ul class="sub-menu">
                                <li class="nav-item">
                                    <a href="all_holidays.html" class="nav-link "> <span class="title">{% trans %} All Holiday  {% endtrans %} Classes</span>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="add_holiday.html" class="nav-link "> <span class="title">Add Holiday</span>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="add_holiday_bootstrap.html" class="nav-link "> <span class="title">Add Holiday Bootstrap</span>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="edit_holiday.html" class="nav-link "> <span class="title">Edit  Holiday</span>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="##" class="nav-link "> <span class="title">Holiday Calendar</span>
                                    </a>
                                </li>
                            </ul> 
                        </li>

                        <li class="nav-item">
                            <a href="#" class="nav-link nav-toggle"> <i class="material-icons">monetization_on</i>
                                <span class="title">Extra school event</span> <span class="arrow"></span>
                            </a>
                            <ul class="sub-menu">
                                <li class="nav-item">
                                    <a href="###" class="nav-link "> <span class="title">Fees Collection</span>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="##" class="nav-link "> <span class="title">Add Fees </span>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="##" class="nav-link "> <span class="title">Add Fees Bootstrap</span>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="##" class="nav-link "> <span class="title">Fee Receipt</span>
                                    </a>
                                </li>
                            </ul>
                        </li>
-->
                   <!--     <li class="nav-item">
                            <a href="#" class="nav-link nav-toggle">
                                <i class="material-icons">email</i>
                                <span class="title">About Us</span>
                                <span class="arrow"></span>
                                <span class="label label-rouded label-menu label-danger">new</span>
                            </a>
                            <ul class="sub-menu">
                                <li class="nav-item">
                                    <a href="email_inbox.html" class="nav-link ">
                                        <span class="title">Inbox</span>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="email_view.html" class="nav-link ">
                                        <span class="title">View Mail</span>
                                    </a>
                                </li>
                                <li class="nav-item">
                                    <a href="email_compose.html" class="nav-link ">
                                        <span class="title">Compose Mail</span>
                                    </a>
                                </li>
                            </ul>
                        </li> -->
                    
                           <div>
                               
            </div>
                </div>
                   
            </div>
        </div>
                                    <!-- end sidebar menu -->
        <!-- start page content -->


                <div class="page-content-wrapper">
    <div class="page-content" style="min-height:702.167px">
        <div class="page-bar">
            <div class="page-title-breadcrumb">
                <div class=" pull-left">
                    <div class="page-title">Dashboard</div>
                </div>
                <ol class="breadcrumb page-breadcrumb pull-right">
                    <li><i class="fa fa-home"></i>&nbsp;<a class="parent-item" href="/rapmis/web/">Home</a>&nbsp;<i class="fa fa-angle-right"></i>
                    </li>
                    <li class="active">Dashboard</li>
                </ol>
            </div>
        </div>
        <div class="row">
            <div class="col-md-12">
                <div class="card card-topline-red">
                    <div class="card-head">
                        <header>SCHOOL LIST</header>
                        <div class="tools">
                            <a class="fa fa-repeat btn-color box-refresh" href="javascript:;"></a>
                            <a class="t-collapse btn-color fa fa-chevron-down" href="javascript:;"></a>
                            <a class="t-close btn-color fa fa-times" href="javascript:;"></a>
                        </div>
                    </div>
                    <div class="card-body ">
                        <div class="row">
                            <div class="col-md-6 col-sm-6 col-6">








                                <div class="btn-group">
                                    <!-- Button trigger modal -->
                                    <button type="button" id="addRow1" class="btn btn-info" data-toggle="modal" data-target="#exampleModalCenter">
                                        Add New School<i class="fa fa-plus"></i>
                                    </button>
                                </div>
                                <!-- Modal -->
                                <div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                                    <div class="modal-dialog modal-dialog-centered" role="document">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title" id="exampleModalLongTitle">{% trans %}What kind of school do you want to create{% endtrans %}?</h5>
                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                    <span aria-hidden="true">×</span>
                                                </button>
                                            </div>
                                            <div class="modal-body">


                                                <div class="col-sm-12">
                                                    <div class="card  card-box">
                                                        <div class="card-head">
                                                            <header>Faites votre choix :</header>
                                                        </div>
                                                        <div class="card-body ">
                                                            <a href="/rapmis/web/etablissements/news/Maternelle"><button type="button" class="btn btn-default btn-circle dropdown-toggle m-r-20">{% trans %} Nursery School {% endtrans %}</button></a>
                                                            <a href="/rapmis/web/etablissements/news/Primaire"><button type="button" class="btn btn-info btn-circle dropdown-toggle m-r-20 ">Ecole Primaire</button></a><br><br><br>
                                                            <a href="/rapmis/web/etablissements/news/Secondaire"><button type="button" class="btn btn-success btn-circle dropdown-toggle m-r-20">Ecole secondaire</button></a>
                                                            <a href="/rapmis/web/etablissements/news/Universite"><button type="button" class="btn btn-primary btn-circle dropdown-toggle m-r-20">Institut Universitaire</button></a>


                                                        </div>
                                                    </div>
                                                </div>


                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>




                            </div>
                            <div class="col-md-6 col-sm-6 col-6">
                                <div class="btn-group pull-right">
                                    <button class="btn deepPink-bgcolor  btn-outline dropdown-toggle" data-toggle="dropdown">Tools
                                        <i class="fa fa-angle-down"></i>
                                    </button>
                                    <ul class="dropdown-menu pull-right">
                                        <li>
                                            <a href="javascript:;">
                                                <i class="fa fa-print"></i> Print </a>
                                        </li>
                                        <li>
                                            <a href="javascript:;">
                                                <i class="fa fa-file-pdf-o"></i> Save as PDF </a>
                                        </li>
                                        <li>
                                            <a href="javascript:;">
                                                <i class="fa fa-file-excel-o"></i> Export to Excel </a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="table-scrollable">
                            <div id="example4_wrapper" class="dataTables_wrapper container-fluid dt-bootstrap4 no-footer"><div class="row"><div class="col-sm-12 col-md-6"><div class="dataTables_length" id="example4_length"><label>Show <select name="example4_length" aria-controls="example4" class="form-control form-control-sm"><option value="10">10</option><option value="25">25</option><option value="50">50</option><option value="100">100</option></select> entries</label></div></div><div class="col-sm-12 col-md-6"><div id="example4_filter" class="dataTables_filter"><label>Search:<input type="search" class="form-control form-control-sm" placeholder="" aria-controls="example4"></label></div></div></div><div class="row"><div class="col-sm-12"><table class="table table-striped table-bordered table-hover table-checkable order-column dataTable no-footer" style="width: 100%;" id="example4" role="grid" aria-describedby="example4_info">
                                <thead>
                                <tr role="row"><th class="sorting_asc" tabindex="0" aria-controls="example4" rowspan="1" colspan="1" style="width: 40.0833px;" aria-sort="ascending" aria-label="
                                        
                                            
                                            
                                        
                                    : activate to sort column descending">
                                        <label class="rt-chkbox rt-chkbox-single rt-chkbox-outline">
                                            <input type="checkbox" class="group-checkable" data-set="#sample_1 .checkboxes">
                                            <span></span>
                                        </label>
                                    </th><th class="sorting" tabindex="0" aria-controls="example4" rowspan="1" colspan="1" style="width: 6.08333px;" aria-label=": activate to sort column ascending"></th><th class="sorting" tabindex="0" aria-controls="example4" rowspan="1" colspan="1" style="width: 138.083px;" aria-label=" Username : activate to sort column ascending"> Username </th><th class="sorting" tabindex="0" aria-controls="example4" rowspan="1" colspan="1" style="width: 42.0833px;" aria-label=" Sigle : activate to sort column ascending"> Sigle </th><th class="sorting" tabindex="0" aria-controls="example4" rowspan="1" colspan="1" style="width: 58.0833px;" aria-label=" Joined : activate to sort column ascending"> Joined </th><th class="sorting" tabindex="0" aria-controls="example4" rowspan="1" colspan="1" style="width: 56.0833px;" aria-label=" School Type : activate to sort column ascending"> School Type </th><th class="sorting" tabindex="0" aria-controls="example4" rowspan="1" colspan="1" style="width: 169.083px;" aria-label=" Description : activate to sort column ascending"> Description </th><th class="sorting" tabindex="0" aria-controls="example4" rowspan="1" colspan="1" style="width: 52px;" aria-label=" Actions : activate to sort column ascending"> Actions </th></tr>
                                </thead>
                                <tbody>



                                
                                    

                                    
                                
                                    

                                    
                                
                                    

                                    
                                
                                    

                                    
                                
                                    

                                    
                                
                                    

                                    
                                
                                    

                                    
                                
                                    

                                    
                                
                                    

                                    
                                
                                    

                                    
                                
                                    

                                    
                                
                                    

                                    
                                
                                    

                                    
                                
                                <tr class="gradeX odd" role="row">
                                        <td class="sorting_1">
                                            <label class="rt-chkbox rt-chkbox-single rt-chkbox-outline">
                                                <input type="checkbox" class="checkboxes" value="1">
                                                <span></span>
                                            </label>
                                        </td>
                                        <td class="patient-img"><img src="/rapmis/web/uploads/logo/" alt="" width="32px" height="32px"></td>
                                        <td>INSTITUT D'ENSEIGNEMENT SECONDAIRE BILINGUE DE BONANJINJE</td>
                                        <td>IESBB</td>
                                        <td>2019-11-30 12:00:00</td>
                                        <td>Secondaire</td>
                                        <td>IESBB (INSTITUT D'ENSEIGNEMENT SECONDAIRE BILINGUE DE BONANJINJE) - SITUE AU GRAND MOULIN - PRINCIPAL : NDJO JACQUES - CONTACTS 699921892</td>
                                        <td class="valigntop">
                                                    

                                            <div class="btn-group">
                                                <button class="btn btn-xs deepPink-bgcolor dropdown-toggle no-margin" type="button" data-toggle="dropdown" aria-expanded="false"> Actions
                                                    <i class="fa fa-angle-down"></i>
                                                </button>

                                                <ul class="dropdown-menu" role="menu">
                                                    <li>
                                                        <a href="/rapmis/web/classes/classes_per_year/1">
                                                            <i class="icon-docs"></i> Class List </a>
                                                    </li>
                                                                                                            <li>
                                                        <a href="/rapmis/web/classes/classes_with_year/1/1">
                                                            <i class="icon-docs"></i> 2020 / 2021</a>
                                                    </li>
                                                                                                        <li>
                                                        <a href="/rapmis/web/classes/classes_with_year/1/2">
                                                            <i class="icon-docs"></i> 2019 / 2020</a>
                                                    </li>
                                                                                                        <li>
                                                        <a href="/rapmis/web/etablissements/1/edit">
                                                            <i class="icon-tag"></i> Edit  School </a>
                                                    </li>
                                                    <li><!--
                                                        <a href="/rapmis/web/use/teacher">
                                                            <i class="icon-user"></i> New User (teacher) </a>
                                                    </li>
                                                    <li>
                                                        <a href="/rapmis/web/use/staff">
                                                            <i class="fa fa-user"></i> New User (staff)</a>
                                                    </li>
                                                    <li class="divider"> </li>
                                                    <li>
                                                        <a href="javascript:;">
                                                            <i class="icon-flag"></i> Comments
                                                            <span class="badge badge-success">4</span>
                                                        </a>
                                                    </li>-->
                                                </li></ul>
                                            </div>
                                                            

                                        </td>
                                    </tr><tr class="gradeX even" role="row">
                                        <td class="sorting_1">
                                            <label class="rt-chkbox rt-chkbox-single rt-chkbox-outline">
                                                <input type="checkbox" class="checkboxes" value="1">
                                                <span></span>
                                            </label>
                                        </td>
                                        <td class="patient-img"><img src="/rapmis/web/uploads/logo/" alt="" width="32px" height="32px"></td>
                                        <td>GROUPE SCOLAIRE BILINGUE LA RENAISSANCE JEANNE ET MATHIEU</td>
                                        <td></td>
                                        <td>2019-11-30 12:00:00</td>
                                        <td>Primaire</td>
                                        <td>GROUPE SCOLAIRE BILINGUE LA RENAISSANCE JEANNE ET MATHIEU - SITUE A LA CITE SIC PRES DU STADE CICAM - DIRECTRICE : ADELINE NKUELIFACK - CONTACT 679110932</td>
                                        <td class="valigntop">
                                                    

                                            <div class="btn-group">
                                                <button class="btn btn-xs deepPink-bgcolor dropdown-toggle no-margin" type="button" data-toggle="dropdown" aria-expanded="false"> Actions
                                                    <i class="fa fa-angle-down"></i>
                                                </button>

                                                <ul class="dropdown-menu" role="menu">
                                                    <li>
                                                        <a href="/rapmis/web/classes/classes_per_year/2">
                                                            <i class="icon-docs"></i> Class List </a>
                                                    </li>
                                                                                                            <li>
                                                        <a href="/rapmis/web/classes/classes_with_year/2/1">
                                                            <i class="icon-docs"></i> 2020 / 2021</a>
                                                    </li>
                                                                                                        <li>
                                                        <a href="/rapmis/web/classes/classes_with_year/2/2">
                                                            <i class="icon-docs"></i> 2019 / 2020</a>
                                                    </li>
                                                                                                        <li>
                                                        <a href="/rapmis/web/etablissements/2/edit">
                                                            <i class="icon-tag"></i> Edit  School </a>
                                                    </li>
                                                    <li><!--
                                                        <a href="/rapmis/web/use/teacher">
                                                            <i class="icon-user"></i> New User (teacher) </a>
                                                    </li>
                                                    <li>
                                                        <a href="/rapmis/web/use/staff">
                                                            <i class="fa fa-user"></i> New User (staff)</a>
                                                    </li>
                                                    <li class="divider"> </li>
                                                    <li>
                                                        <a href="javascript:;">
                                                            <i class="icon-flag"></i> Comments
                                                            <span class="badge badge-success">4</span>
                                                        </a>
                                                    </li>-->
                                                </li></ul>
                                            </div>
                                                            

                                        </td>
                                    </tr><tr class="gradeX odd" role="row">
                                        <td class="sorting_1">
                                            <label class="rt-chkbox rt-chkbox-single rt-chkbox-outline">
                                                <input type="checkbox" class="checkboxes" value="1">
                                                <span></span>
                                            </label>
                                        </td>
                                        <td class="patient-img"><img src="/rapmis/web/uploads/logo/" alt="" width="32px" height="32px"></td>
                                        <td>GROUPE SCOLAIRE BILINGUE LES DINOSAURES</td>
                                        <td></td>
                                        <td>2019-11-30 13:00:00</td>
                                        <td>Primaire</td>
                                        <td>GROUPE SCOLAIRE BILINGUE LES DINOSAURES - SITUE AU CARREFOUR CONQUETE BEEDI - DIRECTRICE : DJUITCHA SYLVIE</td>
                                        <td class="valigntop">
                                                    

                                            <div class="btn-group">
                                                <button class="btn btn-xs deepPink-bgcolor dropdown-toggle no-margin" type="button" data-toggle="dropdown" aria-expanded="false"> Actions
                                                    <i class="fa fa-angle-down"></i>
                                                </button>

                                                <ul class="dropdown-menu" role="menu">
                                                    <li>
                                                        <a href="/rapmis/web/classes/classes_per_year/3">
                                                            <i class="icon-docs"></i> Class List </a>
                                                    </li>
                                                                                                            <li>
                                                        <a href="/rapmis/web/classes/classes_with_year/3/1">
                                                            <i class="icon-docs"></i> 2020 / 2021</a>
                                                    </li>
                                                                                                        <li>
                                                        <a href="/rapmis/web/classes/classes_with_year/3/2">
                                                            <i class="icon-docs"></i> 2019 / 2020</a>
                                                    </li>
                                                                                                        <li>
                                                        <a href="/rapmis/web/etablissements/3/edit">
                                                            <i class="icon-tag"></i> Edit  School </a>
                                                    </li>
                                                    <li><!--
                                                        <a href="/rapmis/web/use/teacher">
                                                            <i class="icon-user"></i> New User (teacher) </a>
                                                    </li>
                                                    <li>
                                                        <a href="/rapmis/web/use/staff">
                                                            <i class="fa fa-user"></i> New User (staff)</a>
                                                    </li>
                                                    <li class="divider"> </li>
                                                    <li>
                                                        <a href="javascript:;">
                                                            <i class="icon-flag"></i> Comments
                                                            <span class="badge badge-success">4</span>
                                                        </a>
                                                    </li>-->
                                                </li></ul>
                                            </div>
                                                            

                                        </td>
                                    </tr><tr class="gradeX even" role="row">
                                        <td class="sorting_1">
                                            <label class="rt-chkbox rt-chkbox-single rt-chkbox-outline">
                                                <input type="checkbox" class="checkboxes" value="1">
                                                <span></span>
                                            </label>
                                        </td>
                                        <td class="patient-img"><img src="/rapmis/web/uploads/logo/20180516_210308.jpg" alt="" width="32px" height="32px"></td>
                                        <td>Lycéé  Bilingue de deido</td>
                                        <td>LYBIDEI</td>
                                        <td>2020-05-29 13:06:46</td>
                                        <td>Secondaire</td>
                                        <td></td>
                                        <td class="valigntop">
                                                    

                                            <div class="btn-group">
                                                <button class="btn btn-xs deepPink-bgcolor dropdown-toggle no-margin" type="button" data-toggle="dropdown" aria-expanded="false"> Actions
                                                    <i class="fa fa-angle-down"></i>
                                                </button>

                                                <ul class="dropdown-menu" role="menu">
                                                    <li>
                                                        <a href="/rapmis/web/classes/classes_per_year/5">
                                                            <i class="icon-docs"></i> Class List </a>
                                                    </li>
                                                                                                            <li>
                                                        <a href="/rapmis/web/classes/classes_with_year/5/1">
                                                            <i class="icon-docs"></i> 2020 / 2021</a>
                                                    </li>
                                                                                                        <li>
                                                        <a href="/rapmis/web/classes/classes_with_year/5/2">
                                                            <i class="icon-docs"></i> 2019 / 2020</a>
                                                    </li>
                                                                                                        <li>
                                                        <a href="/rapmis/web/etablissements/5/edit">
                                                            <i class="icon-tag"></i> Edit  School </a>
                                                    </li>
                                                    <li><!--
                                                        <a href="/rapmis/web/use/teacher">
                                                            <i class="icon-user"></i> New User (teacher) </a>
                                                    </li>
                                                    <li>
                                                        <a href="/rapmis/web/use/staff">
                                                            <i class="fa fa-user"></i> New User (staff)</a>
                                                    </li>
                                                    <li class="divider"> </li>
                                                    <li>
                                                        <a href="javascript:;">
                                                            <i class="icon-flag"></i> Comments
                                                            <span class="badge badge-success">4</span>
                                                        </a>
                                                    </li>-->
                                                </li></ul>
                                            </div>
                                                            

                                        </td>
                                    </tr><tr class="gradeX odd" role="row">
                                        <td class="sorting_1">
                                            <label class="rt-chkbox rt-chkbox-single rt-chkbox-outline">
                                                <input type="checkbox" class="checkboxes" value="1">
                                                <span></span>
                                            </label>
                                        </td>
                                        <td class="patient-img"><img src="/rapmis/web/uploads/logo/" alt="" width="32px" height="32px"></td>
                                        <td>COLLEGE EVANGELIQUE DE NEW BELL</td>
                                        <td>CENB</td>
                                        <td>2020-06-03 21:33:27</td>
                                        <td>Secondaire</td>
                                        <td>COLLEGE D'ENSEIGNEMENT SECONDAIRE GENERAL, TECHNIQUE ET INDUSTRIEL</td>
                                        <td class="valigntop">
                                                    

                                            <div class="btn-group">
                                                <button class="btn btn-xs deepPink-bgcolor dropdown-toggle no-margin" type="button" data-toggle="dropdown" aria-expanded="false"> Actions
                                                    <i class="fa fa-angle-down"></i>
                                                </button>

                                                <ul class="dropdown-menu" role="menu">
                                                    <li>
                                                        <a href="/rapmis/web/classes/classes_per_year/6">
                                                            <i class="icon-docs"></i> Class List </a>
                                                    </li>
                                                                                                            <li>
                                                        <a href="/rapmis/web/classes/classes_with_year/6/1">
                                                            <i class="icon-docs"></i> 2020 / 2021</a>
                                                    </li>
                                                                                                        <li>
                                                        <a href="/rapmis/web/classes/classes_with_year/6/2">
                                                            <i class="icon-docs"></i> 2019 / 2020</a>
                                                    </li>
                                                                                                        <li>
                                                        <a href="/rapmis/web/etablissements/6/edit">
                                                            <i class="icon-tag"></i> Edit  School </a>
                                                    </li>
                                                    <li><!--
                                                        <a href="/rapmis/web/use/teacher">
                                                            <i class="icon-user"></i> New User (teacher) </a>
                                                    </li>
                                                    <li>
                                                        <a href="/rapmis/web/use/staff">
                                                            <i class="fa fa-user"></i> New User (staff)</a>
                                                    </li>
                                                    <li class="divider"> </li>
                                                    <li>
                                                        <a href="javascript:;">
                                                            <i class="icon-flag"></i> Comments
                                                            <span class="badge badge-success">4</span>
                                                        </a>
                                                    </li>-->
                                                </li></ul>
                                            </div>
                                                            

                                        </td>
                                    </tr><tr class="gradeX even" role="row">
                                        <td class="sorting_1">
                                            <label class="rt-chkbox rt-chkbox-single rt-chkbox-outline">
                                                <input type="checkbox" class="checkboxes" value="1">
                                                <span></span>
                                            </label>
                                        </td>
                                        <td class="patient-img"><img src="/rapmis/web/uploads/logo/" alt="" width="32px" height="32px"></td>
                                        <td>LYCEE DE MAKEPE</td>
                                        <td>LYMAK</td>
                                        <td>2020-06-03 21:38:19</td>
                                        <td>Secondaire</td>
                                        <td>ETABLISSEMENT PUBLIC D'ENSEIGNEMENT SECONDAIRE GENERAL</td>
                                        <td class="valigntop">
                                                    

                                            <div class="btn-group">
                                                <button class="btn btn-xs deepPink-bgcolor dropdown-toggle no-margin" type="button" data-toggle="dropdown" aria-expanded="false"> Actions
                                                    <i class="fa fa-angle-down"></i>
                                                </button>

                                                <ul class="dropdown-menu" role="menu">
                                                    <li>
                                                        <a href="/rapmis/web/classes/classes_per_year/7">
                                                            <i class="icon-docs"></i> Class List </a>
                                                    </li>
                                                                                                            <li>
                                                        <a href="/rapmis/web/classes/classes_with_year/7/1">
                                                            <i class="icon-docs"></i> 2020 / 2021</a>
                                                    </li>
                                                                                                        <li>
                                                        <a href="/rapmis/web/classes/classes_with_year/7/2">
                                                            <i class="icon-docs"></i> 2019 / 2020</a>
                                                    </li>
                                                                                                        <li>
                                                        <a href="/rapmis/web/etablissements/7/edit">
                                                            <i class="icon-tag"></i> Edit  School </a>
                                                    </li>
                                                    <li><!--
                                                        <a href="/rapmis/web/use/teacher">
                                                            <i class="icon-user"></i> New User (teacher) </a>
                                                    </li>
                                                    <li>
                                                        <a href="/rapmis/web/use/staff">
                                                            <i class="fa fa-user"></i> New User (staff)</a>
                                                    </li>
                                                    <li class="divider"> </li>
                                                    <li>
                                                        <a href="javascript:;">
                                                            <i class="icon-flag"></i> Comments
                                                            <span class="badge badge-success">4</span>
                                                        </a>
                                                    </li>-->
                                                </li></ul>
                                            </div>
                                                            

                                        </td>
                                    </tr><tr class="gradeX odd" role="row">
                                        <td class="sorting_1">
                                            <label class="rt-chkbox rt-chkbox-single rt-chkbox-outline">
                                                <input type="checkbox" class="checkboxes" value="1">
                                                <span></span>
                                            </label>
                                        </td>
                                        <td class="patient-img"><img src="/rapmis/web/uploads/logo/" alt="" width="32px" height="32px"></td>
                                        <td>LYCEE BILINGUE DE LOGPOM II</td>
                                        <td>LYBILOG 2</td>
                                        <td>2020-06-03 21:42:53</td>
                                        <td>Secondaire</td>
                                        <td>ETABLISSEMENT PUBLIC D'ENSEIGNEMENT SECONDAIRE GENERAL</td>
                                        <td class="valigntop">
                                                    

                                            <div class="btn-group">
                                                <button class="btn btn-xs deepPink-bgcolor dropdown-toggle no-margin" type="button" data-toggle="dropdown" aria-expanded="false"> Actions
                                                    <i class="fa fa-angle-down"></i>
                                                </button>

                                                <ul class="dropdown-menu" role="menu">
                                                    <li>
                                                        <a href="/rapmis/web/classes/classes_per_year/8">
                                                            <i class="icon-docs"></i> Class List </a>
                                                    </li>
                                                                                                            <li>
                                                        <a href="/rapmis/web/classes/classes_with_year/8/1">
                                                            <i class="icon-docs"></i> 2020 / 2021</a>
                                                    </li>
                                                                                                        <li>
                                                        <a href="/rapmis/web/classes/classes_with_year/8/2">
                                                            <i class="icon-docs"></i> 2019 / 2020</a>
                                                    </li>
                                                                                                        <li>
                                                        <a href="/rapmis/web/etablissements/8/edit">
                                                            <i class="icon-tag"></i> Edit  School </a>
                                                    </li>
                                                    <li><!--
                                                        <a href="/rapmis/web/use/teacher">
                                                            <i class="icon-user"></i> New User (teacher) </a>
                                                    </li>
                                                    <li>
                                                        <a href="/rapmis/web/use/staff">
                                                            <i class="fa fa-user"></i> New User (staff)</a>
                                                    </li>
                                                    <li class="divider"> </li>
                                                    <li>
                                                        <a href="javascript:;">
                                                            <i class="icon-flag"></i> Comments
                                                            <span class="badge badge-success">4</span>
                                                        </a>
                                                    </li>-->
                                                </li></ul>
                                            </div>
                                                            

                                        </td>
                                    </tr><tr class="gradeX even" role="row">
                                        <td class="sorting_1">
                                            <label class="rt-chkbox rt-chkbox-single rt-chkbox-outline">
                                                <input type="checkbox" class="checkboxes" value="1">
                                                <span></span>
                                            </label>
                                        </td>
                                        <td class="patient-img"><img src="/rapmis/web/uploads/logo/" alt="" width="32px" height="32px"></td>
                                        <td>LYCEE BILINGUE DE BONABERI</td>
                                        <td>LYBIBO</td>
                                        <td>2020-06-03 22:00:07</td>
                                        <td>Secondaire</td>
                                        <td>ETABLISSEMENT PUBLIC BILINGUE D'ENSEIGNEMENT SECONDAIRE</td>
                                        <td class="valigntop">
                                                    

                                            <div class="btn-group">
                                                <button class="btn btn-xs deepPink-bgcolor dropdown-toggle no-margin" type="button" data-toggle="dropdown" aria-expanded="false"> Actions
                                                    <i class="fa fa-angle-down"></i>
                                                </button>

                                                <ul class="dropdown-menu" role="menu">
                                                    <li>
                                                        <a href="/rapmis/web/classes/classes_per_year/9">
                                                            <i class="icon-docs"></i> Class List </a>
                                                    </li>
                                                                                                            <li>
                                                        <a href="/rapmis/web/classes/classes_with_year/9/1">
                                                            <i class="icon-docs"></i> 2020 / 2021</a>
                                                    </li>
                                                                                                        <li>
                                                        <a href="/rapmis/web/classes/classes_with_year/9/2">
                                                            <i class="icon-docs"></i> 2019 / 2020</a>
                                                    </li>
                                                                                                        <li>
                                                        <a href="/rapmis/web/etablissements/9/edit">
                                                            <i class="icon-tag"></i> Edit  School </a>
                                                    </li>
                                                    <li><!--
                                                        <a href="/rapmis/web/use/teacher">
                                                            <i class="icon-user"></i> New User (teacher) </a>
                                                    </li>
                                                    <li>
                                                        <a href="/rapmis/web/use/staff">
                                                            <i class="fa fa-user"></i> New User (staff)</a>
                                                    </li>
                                                    <li class="divider"> </li>
                                                    <li>
                                                        <a href="javascript:;">
                                                            <i class="icon-flag"></i> Comments
                                                            <span class="badge badge-success">4</span>
                                                        </a>
                                                    </li>-->
                                                </li></ul>
                                            </div>
                                                            

                                        </td>
                                    </tr><tr class="gradeX odd" role="row">
                                        <td class="sorting_1">
                                            <label class="rt-chkbox rt-chkbox-single rt-chkbox-outline">
                                                <input type="checkbox" class="checkboxes" value="1">
                                                <span></span>
                                            </label>
                                        </td>
                                        <td class="patient-img"><img src="/rapmis/web/uploads/logo/" alt="" width="32px" height="32px"></td>
                                        <td>CETIC DE MABANDA</td>
                                        <td>CETMAB</td>
                                        <td>2020-06-03 22:06:38</td>
                                        <td>Secondaire</td>
                                        <td>ETABLISSEMENT PUBLIC  D'ENSEIGNEMENT TECHNIQUE INDUSTRIEL ET COMMERCIAL DU 1ER CYCLE</td>
                                        <td class="valigntop">
                                                    

                                            <div class="btn-group">
                                                <button class="btn btn-xs deepPink-bgcolor dropdown-toggle no-margin" type="button" data-toggle="dropdown" aria-expanded="false"> Actions
                                                    <i class="fa fa-angle-down"></i>
                                                </button>

                                                <ul class="dropdown-menu" role="menu">
                                                    <li>
                                                        <a href="/rapmis/web/classes/classes_per_year/10">
                                                            <i class="icon-docs"></i> Class List </a>
                                                    </li>
                                                                                                            <li>
                                                        <a href="/rapmis/web/classes/classes_with_year/10/1">
                                                            <i class="icon-docs"></i> 2020 / 2021</a>
                                                    </li>
                                                                                                        <li>
                                                        <a href="/rapmis/web/classes/classes_with_year/10/2">
                                                            <i class="icon-docs"></i> 2019 / 2020</a>
                                                    </li>
                                                                                                        <li>
                                                        <a href="/rapmis/web/etablissements/10/edit">
                                                            <i class="icon-tag"></i> Edit  School </a>
                                                    </li>
                                                    <li><!--
                                                        <a href="/rapmis/web/use/teacher">
                                                            <i class="icon-user"></i> New User (teacher) </a>
                                                    </li>
                                                    <li>
                                                        <a href="/rapmis/web/use/staff">
                                                            <i class="fa fa-user"></i> New User (staff)</a>
                                                    </li>
                                                    <li class="divider"> </li>
                                                    <li>
                                                        <a href="javascript:;">
                                                            <i class="icon-flag"></i> Comments
                                                            <span class="badge badge-success">4</span>
                                                        </a>
                                                    </li>-->
                                                </li></ul>
                                            </div>
                                                            

                                        </td>
                                    </tr><tr class="gradeX even" role="row">
                                        <td class="sorting_1">
                                            <label class="rt-chkbox rt-chkbox-single rt-chkbox-outline">
                                                <input type="checkbox" class="checkboxes" value="1">
                                                <span></span>
                                            </label>
                                        </td>
                                        <td class="patient-img"><img src="/rapmis/web/uploads/logo/" alt="" width="32px" height="32px"></td>
                                        <td>LYCEE BILINGUE DE MOUANKO</td>
                                        <td>LYBIMOUAN</td>
                                        <td>2020-06-03 22:11:15</td>
                                        <td>Secondaire</td>
                                        <td>ETABLISSEMENT PUBLIC BILINGUE D'ENSEI
GNEMENT SECONDAIRE GENERAL</td>
                                        <td class="valigntop">
                                                    

                                            <div class="btn-group">
                                                <button class="btn btn-xs deepPink-bgcolor dropdown-toggle no-margin" type="button" data-toggle="dropdown" aria-expanded="false"> Actions
                                                    <i class="fa fa-angle-down"></i>
                                                </button>

                                                <ul class="dropdown-menu" role="menu">
                                                    <li>
                                                        <a href="/rapmis/web/classes/classes_per_year/11">
                                                            <i class="icon-docs"></i> Class List </a>
                                                    </li>
                                                                                                            <li>
                                                        <a href="/rapmis/web/classes/classes_with_year/11/1">
                                                            <i class="icon-docs"></i> 2020 / 2021</a>
                                                    </li>
                                                                                                        <li>
                                                        <a href="/rapmis/web/classes/classes_with_year/11/2">
                                                            <i class="icon-docs"></i> 2019 / 2020</a>
                                                    </li>
                                                                                                        <li>
                                                        <a href="/rapmis/web/etablissements/11/edit">
                                                            <i class="icon-tag"></i> Edit  School </a>
                                                    </li>
                                                    <li><!--
                                                        <a href="/rapmis/web/use/teacher">
                                                            <i class="icon-user"></i> New User (teacher) </a>
                                                    </li>
                                                    <li>
                                                        <a href="/rapmis/web/use/staff">
                                                            <i class="fa fa-user"></i> New User (staff)</a>
                                                    </li>
                                                    <li class="divider"> </li>
                                                    <li>
                                                        <a href="javascript:;">
                                                            <i class="icon-flag"></i> Comments
                                                            <span class="badge badge-success">4</span>
                                                        </a>
                                                    </li>-->
                                                </li></ul>
                                            </div>
                                                            

                                        </td>
                                    </tr></tbody>
                            </table></div></div><div class="row"><div class="col-sm-12 col-md-5"><div class="dataTables_info" id="example4_info" role="status" aria-live="polite">Showing 1 to 10 of 13 entries</div></div><div class="col-sm-12 col-md-7"><div class="dataTables_paginate paging_simple_numbers" id="example4_paginate"><ul class="pagination"><li class="paginate_button page-item previous disabled" id="example4_previous"><a href="#" aria-controls="example4" data-dt-idx="0" tabindex="0" class="page-link">Previous</a></li><li class="paginate_button page-item active"><a href="#" aria-controls="example4" data-dt-idx="1" tabindex="0" class="page-link">1</a></li><li class="paginate_button page-item "><a href="#" aria-controls="example4" data-dt-idx="2" tabindex="0" class="page-link">2</a></li><li class="paginate_button page-item next" id="example4_next"><a href="#" aria-controls="example4" data-dt-idx="3" tabindex="0" class="page-link">Next</a></li></ul></div></div></div></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>



    </div>
</div>


<!-- end page content -->
<!-- start chat sidebar -->
<div class="chat-sidebar-container" data-close-on-body-click="false">
       <!-- <div class="chat-sidebar">
        <ul class="nav nav-tabs">
            <li class="nav-item">
                <a href="#quick_sidebar_tab_1" class="nav-link active tab-icon"  data-toggle="tab"> <i class="material-icons">chat</i>Chat
                    <span class="badge badge-danger">4</span>
                </a>
            </li>
            <li class="nav-item">
                <a href="#quick_sidebar_tab_3" class="nav-link tab-icon"  data-toggle="tab"> <i class="material-icons">settings</i> Settings
                </a>
            </li>
        </ul>
        <div class="tab-content">
            <!-- Start Doctor Chat 
            <div class="tab-pane active chat-sidebar-chat in active show" role="tabpanel" id="quick_sidebar_tab_1">
                <div class="chat-sidebar-list">
                    <div class="chat-sidebar-chat-users slimscroll-style" data-rail-color="#ddd" data-wrapper-class="chat-sidebar-list">
                        <div class="chat-header"><h5 class="list-heading">Online</h5></div>
                        <ul class="media-list list-items">
                            <li class="media"><img class="media-object" src="/rapmis/web/assets/img/prof/prof3.jpg" width="35" height="35" alt="...">
                                <i class="online dot"></i>
                                <div class="media-body">
                                    <h5 class="media-heading">John Deo</h5>
                                    <div class="media-heading-sub">Spine Surgeon</div>
                                </div>
                            </li>
                            <li class="media">
                                <div class="media-status">
                                    <span class="badge badge-success">5</span>
                                </div> <img class="media-object" src="/rapmis/web/assets/img/prof/prof1.jpg" width="35" height="35" alt="...">
                                <i class="busy dot"></i>
                                <div class="media-body">
                                    <h5 class="media-heading">Rajesh</h5>
                                    <div class="media-heading-sub">Director</div>
                                </div>
                            </li>
                            <li class="media"><img class="media-object" src="/rapmis/web/assets/img/prof/prof5.jpg" width="35" height="35" alt="...">
                                <i class="away dot"></i>
                                <div class="media-body">
                                    <h5 class="media-heading">Jacob Ryan</h5>
                                    <div class="media-heading-sub">Ortho Surgeon</div>
                                </div>
                            </li>
                            <li class="media">
                                <div class="media-status">
                                    <span class="badge badge-danger">8</span>
                                </div> <img class="media-object" src="/rapmis/web/assets/img/prof/prof4.jpg" width="35" height="35" alt="...">
                                <i class="online dot"></i>
                                <div class="media-body">
                                    <h5 class="media-heading">Kehn Anderson</h5>
                                    <div class="media-heading-sub">CEO</div>
                                </div>
                            </li>
                            <li class="media"><img class="media-object" src="/rapmis/web/assets/img/prof/prof2.jpg" width="35" height="35" alt="...">
                                <i class="busy dot"></i>
                                <div class="media-body">
                                    <h5 class="media-heading">Sarah Smith</h5>
                                    <div class="media-heading-sub">Anaesthetics</div>
                                </div>
                            </li>
                            <li class="media"><img class="media-object" src="/rapmis/web/assets/img/prof/prof7.jpg" width="35" height="35" alt="...">
                                <i class="online dot"></i>
                                <div class="media-body">
                                    <h5 class="media-heading">Vlad Cardella</h5>
                                    <div class="media-heading-sub">Cardiologist</div>
                                </div>
                            </li>
                        </ul>
                        <div class="chat-header"><h5 class="list-heading">Offline</h5></div>
                        <ul class="media-list list-items">
                            <li class="media">
                                <div class="media-status">
                                    <span class="badge badge-warning">4</span>
                                </div> <img class="media-object" src="/rapmis/web/assets/img/prof/prof6.jpg" width="35" height="35" alt="...">
                                <i class="offline dot"></i>
                                <div class="media-body">
                                    <h5 class="media-heading">Jennifer Maklen</h5>
                                    <div class="media-heading-sub">Nurse</div>
                                    <div class="media-heading-small">Last seen 01:20 AM</div>
                                </div>
                            </li>
                            <li class="media"><img class="media-object" src="/rapmis/web/assets/img/prof/prof8.jpg" width="35" height="35" alt="...">
                                <i class="offline dot"></i>
                                <div class="media-body">
                                    <h5 class="media-heading">Lina Smith</h5>
                                    <div class="media-heading-sub">Ortho Surgeon</div>
                                    <div class="media-heading-small">Last seen 11:14 PM</div>
                                </div>
                            </li>
                            <li class="media">
                                <div class="media-status">
                                    <span class="badge badge-success">9</span>
                                </div> <img class="media-object" src="/rapmis/web/assets/img/prof/prof9.jpg" width="35" height="35" alt="...">
                                <i class="offline dot"></i>
                                <div class="media-body">
                                    <h5 class="media-heading">Jeff Adam</h5>
                                    <div class="media-heading-sub">Compounder</div>
                                    <div class="media-heading-small">Last seen 3:31 PM</div>
                                </div>
                            </li>
                            <li class="media"><img class="media-object" src="/rapmis/web/assets/img/prof/prof10.jpg" width="35" height="35" alt="...">
                                <i class="offline dot"></i>
                                <div class="media-body">
                                    <h5 class="media-heading">Anjelina Cardella</h5>
                                    <div class="media-heading-sub">Physiotherapist</div>
                                    <div class="media-heading-small">Last seen 7:45 PM</div>
                                </div>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="chat-sidebar-item">
                    <div class="chat-sidebar-chat-user">
                        <div class="page-quick-sidemenu">
                            <a href="javascript:;" class="chat-sidebar-back-to-list">
                                <i class="fa fa-angle-double-left"></i>Back
                            </a>
                        </div>
                        <div class="chat-sidebar-chat-user-messages">
                            <div class="post out">
                                                                                                <img class="avatar" alt="" src="/rapmis/web/uploads/app.user.photoDeProfil" width="32px" />    
                                                                                                    <div class="message">
                                    <span class="arrow"></span> <a href="javascript:;" class="name">devalere</a> <span class="datetime">9:10</span>
                                    <span class="body-out"> could you send me menu icons ? </span>
                                </div>
                            </div>
                            <div class="post in">
                                <img class="avatar" alt="" src="/rapmis/web/assets/img/prof/prof5.jpg" />
                                <div class="message">
                                    <span class="arrow"></span> <a href="javascript:;" class="name">Jacob Ryan</a> <span class="datetime">9:10</span>
                                    <span class="body"> please give me 10 minutes. </span>
                                </div>
                            </div>
                            <div class="post out">
                                <img class="avatar" alt="" src="/rapmis/web/uploads/prof/devalere.png" />
                                <div class="message">
                                    <span class="arrow"></span> <a href="javascript:;" class="name">devalere</a> <span class="datetime">9:11</span>
                                    <span class="body-out"> ok fine :) </span>
                                </div>
                            </div>
                            <div class="post in">
                                <img class="avatar" alt="" src="/rapmis/web/assets/img/prof/prof5.jpg" />
                                <div class="message">
                                    <span class="arrow"></span> <a href="javascript:;" class="name">Jacob Ryan</a> <span class="datetime">9:22</span>
                                    <span class="body">Sorry for
													the delay. i sent mail to you. let me know if it is ok or not.</span>
                                </div>
                            </div>
                            <div class="post out">
                                <img class="avatar" alt="" src="/rapmis/web/uploads/prof/devalere.png" />
                                <div class="message">
                                    <span class="arrow"></span> <a href="javascript:;" class="name">devalere</a> <span class="datetime">9:26</span>
                                    <span class="body-out"> it is perfect! :) </span>
                                </div>
                            </div>
                            <div class="post out">
                                <img class="avatar" alt="" src="/rapmis/web/uploads/prof/devalere.png" />
                                <div class="message">
                                    <span class="arrow"></span> <a href="javascript:;" class="name">devalere</a> <span class="datetime">9:26</span>
                                    <span class="body-out"> Great! Thanks. </span>
                                </div>
                            </div>
                            <div class="post in">
                                <img class="avatar" alt="" src="/rapmis/web/assets/img/prof/prof5.jpg" />
                                <div class="message">
                                    <span class="arrow"></span> <a href="javascript:;" class="name">Jacob Ryan</a> <span class="datetime">9:27</span>
                                    <span class="body"> it is my pleasure :) </span>
                                </div>
                            </div>
                        </div>
                        <div class="chat-sidebar-chat-user-form">
                            <div class="input-group">
                                <input type="text" class="form-control" placeholder="Type a message here...">
                                <div class="input-group-btn">
                                    <button type="button" class="btn deepPink-bgcolor">
                                        <i class="fa fa-arrow-right"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- End Doctor Chat -->
            <!-- Start Setting Panel -->
            <div class="tab-pane chat-sidebar-settings" role="tabpanel" id="quick_sidebar_tab_3">
                <div class="slimScrollDiv" style="position: relative; overflow: hidden; width: auto; height: 585px;"><div class="chat-sidebar-settings-list slimscroll-style" data-height="NaN" style="height: 227.833px; overflow: hidden auto; width: auto;">
                    <div class="chat-header"><h5 class="list-heading">Layout Settings</h5></div>
                    <div class="chatpane inner-content ">
                        <div class="settings-list">
                            <div class="setting-item">
                                <div class="setting-text">Sidebar Position</div>
                                <div class="setting-set">
                                    <select class="sidebar-pos-option form-control input-inline input-sm input-small ">
                                        <option value="left" selected="selected">Left</option>
                                        <option value="right">Right</option>
                                    </select>
                                </div>
                            </div>
                            <div class="setting-item">
                                <div class="setting-text">Header</div>
                                <div class="setting-set">
                                    <select class="page-header-option form-control input-inline input-sm input-small ">
                                        <option value="fixed" selected="selected">Fixed</option>
                                        <option value="default">Default</option>
                                    </select>
                                </div>
                            </div>
                            <div class="setting-item">
                                <div class="setting-text">Sidebar Menu </div>
                                <div class="setting-set">
                                    <select class="sidebar-menu-option form-control input-inline input-sm input-small ">
                                        <option value="accordion" selected="selected">Accordion</option>
                                        <option value="hover">Hover</option>
                                    </select>
                                </div>
                            </div>
                            <div class="setting-item">
                                <div class="setting-text">Footer</div>
                                <div class="setting-set">
                                    <select class="page-footer-option form-control input-inline input-sm input-small ">
                                        <option value="fixed">Fixed</option>
                                        <option value="default" selected="selected">Default</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="chat-header"><h5 class="list-heading">Account Settings</h5></div>
                        <div class="settings-list">
                            <div class="setting-item">
                                <div class="setting-text">Notifications</div>
                                <div class="setting-set">
                                    <div class="switch">
                                        <label class="mdl-switch mdl-js-switch mdl-js-ripple-effect mdl-js-ripple-effect--ignore-events is-checked is-upgraded" for="switch-1" data-upgraded=",MaterialSwitch,MaterialRipple">
                                            <input type="checkbox" id="switch-1" class="mdl-switch__input" checked="">
                                        <div class="mdl-switch__track"></div><div class="mdl-switch__thumb"><span class="mdl-switch__focus-helper"></span></div><span class="mdl-switch__ripple-container mdl-js-ripple-effect mdl-ripple--center" data-upgraded=",MaterialRipple"><span class="mdl-ripple"></span></span></label>
                                    </div>
                                </div>
                            </div>
                            <div class="setting-item">
                                <div class="setting-text">Show Online</div>
                                <div class="setting-set">
                                    <div class="switch">
                                        <label class="mdl-switch mdl-js-switch mdl-js-ripple-effect mdl-js-ripple-effect--ignore-events is-checked is-upgraded" for="switch-7" data-upgraded=",MaterialSwitch,MaterialRipple">
                                            <input type="checkbox" id="switch-7" class="mdl-switch__input" checked="">
                                        <div class="mdl-switch__track"></div><div class="mdl-switch__thumb"><span class="mdl-switch__focus-helper"></span></div><span class="mdl-switch__ripple-container mdl-js-ripple-effect mdl-ripple--center" data-upgraded=",MaterialRipple"><span class="mdl-ripple"></span></span></label>
                                    </div>
                                </div>
                            </div>
                            <div class="setting-item">
                                <div class="setting-text">Status</div>
                                <div class="setting-set">
                                    <div class="switch">
                                        <label class="mdl-switch mdl-js-switch mdl-js-ripple-effect mdl-js-ripple-effect--ignore-events is-checked is-upgraded" for="switch-2" data-upgraded=",MaterialSwitch,MaterialRipple">
                                            <input type="checkbox" id="switch-2" class="mdl-switch__input" checked="">
                                        <div class="mdl-switch__track"></div><div class="mdl-switch__thumb"><span class="mdl-switch__focus-helper"></span></div><span class="mdl-switch__ripple-container mdl-js-ripple-effect mdl-ripple--center" data-upgraded=",MaterialRipple"><span class="mdl-ripple"></span></span></label>
                                    </div>
                                </div>
                            </div>
                            <div class="setting-item">
                                <div class="setting-text">2 Steps Verification</div>
                                <div class="setting-set">
                                    <div class="switch">
                                        <label class="mdl-switch mdl-js-switch mdl-js-ripple-effect mdl-js-ripple-effect--ignore-events is-checked is-upgraded" for="switch-3" data-upgraded=",MaterialSwitch,MaterialRipple">
                                            <input type="checkbox" id="switch-3" class="mdl-switch__input" checked="">
                                        <div class="mdl-switch__track"></div><div class="mdl-switch__thumb"><span class="mdl-switch__focus-helper"></span></div><span class="mdl-switch__ripple-container mdl-js-ripple-effect mdl-ripple--center" data-upgraded=",MaterialRipple"><span class="mdl-ripple"></span></span></label>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="chat-header"><h5 class="list-heading">General Settings</h5></div>
                        <div class="settings-list">
                            <div class="setting-item">
                                <div class="setting-text">Location</div>
                                <div class="setting-set">
                                    <div class="switch">
                                        <label class="mdl-switch mdl-js-switch mdl-js-ripple-effect mdl-js-ripple-effect--ignore-events is-checked is-upgraded" for="switch-4" data-upgraded=",MaterialSwitch,MaterialRipple">
                                            <input type="checkbox" id="switch-4" class="mdl-switch__input" checked="">
                                        <div class="mdl-switch__track"></div><div class="mdl-switch__thumb"><span class="mdl-switch__focus-helper"></span></div><span class="mdl-switch__ripple-container mdl-js-ripple-effect mdl-ripple--center" data-upgraded=",MaterialRipple"><span class="mdl-ripple"></span></span></label>
                                    </div>
                                </div>
                            </div>
                            <div class="setting-item">
                                <div class="setting-text">Save Histry</div>
                                <div class="setting-set">
                                    <div class="switch">
                                        <label class="mdl-switch mdl-js-switch mdl-js-ripple-effect mdl-js-ripple-effect--ignore-events is-checked is-upgraded" for="switch-5" data-upgraded=",MaterialSwitch,MaterialRipple">
                                            <input type="checkbox" id="switch-5" class="mdl-switch__input" checked="">
                                        <div class="mdl-switch__track"></div><div class="mdl-switch__thumb"><span class="mdl-switch__focus-helper"></span></div><span class="mdl-switch__ripple-container mdl-js-ripple-effect mdl-ripple--center" data-upgraded=",MaterialRipple"><span class="mdl-ripple"></span></span></label>
                                    </div>
                                </div>
                            </div>
                            <div class="setting-item">
                                <div class="setting-text">Auto Updates</div>
                                <div class="setting-set">
                                    <div class="switch">
                                        <label class="mdl-switch mdl-js-switch mdl-js-ripple-effect mdl-js-ripple-effect--ignore-events is-checked is-upgraded" for="switch-6" data-upgraded=",MaterialSwitch,MaterialRipple">
                                            <input type="checkbox" id="switch-6" class="mdl-switch__input" checked="">
                                        <div class="mdl-switch__track"></div><div class="mdl-switch__thumb"><span class="mdl-switch__focus-helper"></span></div><span class="mdl-switch__ripple-container mdl-js-ripple-effect mdl-ripple--center" data-upgraded=",MaterialRipple"><span class="mdl-ripple"></span></span></label>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div><div class="slimScrollBar" style="background: rgb(158, 165, 171) none repeat scroll 0% 0%; width: 5px; position: absolute; top: 0px; opacity: 0.4; display: none; border-radius: 7px; z-index: 99; right: 1px; height: 585px;"></div><div class="slimScrollRail" style="width: 5px; height: 100%; position: absolute; top: 0px; display: none; border-radius: 7px; background: rgb(51, 51, 51) none repeat scroll 0% 0%; opacity: 0.2; z-index: 90; right: 1px;"></div></div>
            </div>
        </div>
    </div>

</div>
<!-- end chat sidebar -->

<!-- end page container  -->
<!-- start footer -->
<div class="page-footer">
    <div class="page-footer-inner">© Copyright 2020 RapMis By
        <a href="https://habitechsolution.com/" target="blank" class="makerCss">HABITECH SOLUTIONS <strong>&amp;</strong> SERVICES</a>
    </div>
    <div class="scroll-to-top" style="display: block;">
        <i class="icon-arrow-up"></i>
    </div>

</div>
<!-- end footer -->
<!-- start js include path -->

<script src="/rapmis/web/assets/plugins/jquery/jquery.min.js"></script>
<script src="/rapmis/web/assets/plugins/popper/popper.js"></script>
<script src="/rapmis/web/js/jquery-1.9.1.min.js"></script>
<script src="/rapmis/web/js/Backstretch.js"></script>
<script src="/rapmis/web/js/jquery.countdown.js"></script>
<script src="/rapmis/web/js/global.js"></script>

   
<script src="/rapmis/web/assets/plugins/jquery-blockui/jquery.blockui.min.js"></script>
<script src="/rapmis/web/assets/plugins/jquery-slimscroll/jquery.slimscroll.js"></script>
<script src="/rapmis/web/js/app.js"></script>
<!-- bootstrap -->
<script src="/rapmis/web/assets/plugins/bootstrap/js/bootstrap.min.js"></script>
<script src="/rapmis/web/assets/plugins/bootstrap-switch/js/bootstrap-switch.min.js"></script>
<script src="/rapmis/web/assets/plugins/sparkline/jquery.sparkline.js"></script>
<script src="/rapmis/web/assets/js/pages/sparkline/sparkline-data.js"></script>
<!-- Common js-->
<script src="/rapmis/web/assets/js/app.js"></script>
<script src="/rapmis/web/assets/js/layout.js"></script>
<script src="/rapmis/web/assets/js/theme-color.js"></script>

<!-- material -->
<script src="/rapmis/web/assets/plugins/material/material.min.js"></script>
<!-- chart js -->
<script src="/rapmis/web/assets/plugins/chart-js/Chart.bundle.js"></script>
<script src="/rapmis/web/assets/plugins/chart-js/utils.js"></script>
<script src="/rapmis/web/assets/js/pages/chart/chartjs/home-data.js"></script>
<script src="/rapmis/web/assets/js/pages/chart/chartjs/home-data2.js"></script>
<script src="/rapmis/web/assets/js/pages/chart/chartjs/home-data3.js"></script>
<!-- data tables -->
<script src="/rapmis/web/assets/plugins/datatables/jquery.dataTables.min.js"></script>
<script src="/rapmis/web/assets/plugins/datatables/plugins/bootstrap/dataTables.bootstrap4.min.js"></script>
<script src="/rapmis/web/assets/js/pages/table/table_data.js"></script>
<!-- dropzone -->
<link href="/rapmis/web/assets/plugins/dropzone/dropzone.css" rel="stylesheet" media="screen">
<!-- Date Time item CSS -->
<link rel="stylesheet" href="/rapmis/web/assets/plugins/material-datetimepicker/bootstrap-material-datetimepicker.css">
<!-- calendar -->
<script src="/rapmis/web/assets/plugins/moment/moment.min.js"></script>
<script src="/rapmis/web/assets/plugins/fullcalendar/fullcalendar.min.js"></script>
<script src="/rapmis/web/assets/js/pages/calendar/calendar.min.js"></script>
<!-- summernote -->
<script src="/rapmis/web/assets/plugins/summernote/summernote.js"></script>
<script src="/rapmis/web/assets/js/pages/summernote/summernote-data.js"></script>
<!-- owl carousel -->
<script src="/rapmis/web/assets/plugins/owl-carousel/owl.carousel.js"></script>
<script src="/rapmis/web/assets/js/pages/owl-carousel/owl_data.js"></script>
<!-- end js include path -->




</body>